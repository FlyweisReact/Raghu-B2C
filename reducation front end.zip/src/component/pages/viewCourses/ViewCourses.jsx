/** @format */

import React from "react";
import "./viewCourses.css";
import Nav from "../../Navbar/Nav";
import Topbar from "../../navigation/Topbar";

const ViewCourses = () => {
  return (
    <div className="viewCourses">
      <Topbar />
    </div>
  );
};

export default ViewCourses;
