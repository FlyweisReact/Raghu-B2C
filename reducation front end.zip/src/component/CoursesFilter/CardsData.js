/** @format */

const CardData = [
  {
    id: 1,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "coding",
    catName: "Coding",
  },
  {
    id: 2,
    cardImg: "",
    c: "Aws",
    timesRemains: "8h 15m",
    category: "coding",
  },
  {
    id: 3,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "coding",
  },
  {
    id: 4,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "coding",
  },
  {
    id: 5,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "UI/UX",
  },
  {
    id: 6,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Design",
  },
  {
    id: 7,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Management",
  },
  {
    id: 8,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Finance",
  },
  {
    id: 9,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Civil Services",
  },
  {
    id: 10,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Civil Services",
  },
  {
    id: 11,
    cardImg: "",
    courseName: "Aws",
    timesRemains: "8h 15m",
    category: "Management",
  },
];
export default CardData;
